// TODO: Implement this script
console.error("Simulated error from failing script");
process.exit(1);
