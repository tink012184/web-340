// TODO: Implement this script
const characters = [
  {
    class: "Warrior",
    gender: "Female",
    funFact: "Carries a sword made of enchanted ice.",
  },
  {
    class: "Mage",
    gender: "Male",
    funFact: "Can summon rainstorms with a sneeze.",
  },
  {
    class: "Rogue",
    gender: "Other",
    funFact: "Once pickpocketed a dragon.",
  },
];

console.log(JSON.stringify(characters));
